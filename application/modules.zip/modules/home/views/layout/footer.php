   <footer class="footer mt-5 py-3 bg-light">
     <div class="container">
       <span class="text-primary">&copy; Develop by Karossa Technology Center</span>
     </div>
   </footer>

   <script src="<?= base_url('assets/home/'); ?>js/bootstrap.bundle.min.js"></script>
   <script src="<?= base_url('assets/') ?>js/sweetalert2.all.min.js"></script>
   <script src="<?= base_url('assets/') ?>js/mySwal.js"></script>

   </body>

   </html>