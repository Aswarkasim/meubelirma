<div class="mt-5"></div>
<div class="mt-5"></div>
<div class="container">
  <div class="row">

    <div class="col-md-4">
      <div class="card card-profile">
        <div class="card-avatar mt-3">
          <center>
            <a href="javascript:;">
              <img class="img-raised rounded-circle img-fluid" src="<?= base_url('assets/home/'); ?>assets/img/faces/marc.jpg" width="100px">
            </a>
          </center>
        </div>
        <div class="card-body">
          <h6 class="card-category text-gray">CEO / Co-Founder</h6>
          <h4 class="card-title">Alec Thompson</h4>
          <p class="card-description">
            Don't be scared of the truth because we need to restart the human foundation in truth And I love you like Kanye loves Kanye I love Rick Owens’ bed design but the back is...
          </p>
          <a href="javascript:;" class="btn btn-primary btn-round">Follow</a>
        </div>
      </div>
    </div>


    <div class="col-md-8">
      <div class="card">
        <div class="card-header card-header-primary">
          <ul class="nav nav-tabs" data-tabs="tabs">
            <li class="nav-item">
              <a class="nav-link" href="#profile" data-toggle="tab">
                <i class="material-icons">face</i>
                Profile
                <div class="ripple-container"></div>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link active show" href="#messages" data-toggle="tab">
                <i class="material-icons">chat</i>
                Messages
                <div class="ripple-container"></div>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#settings" data-toggle="tab">
                <i class="material-icons">build</i>
                Settings
                <div class="ripple-container"></div>
              </a>
            </li>
          </ul>
        </div>
        <div class="card-body">
          <form action="">
            <div class="row">
              <div class="col-lg-12">

                <div class="tab-content tab-space">
                  <div class="tab-pane active show" id="dashboard-1">
                    Collaboratively administrate empowered markets via plug-and-play networks. Dynamically procrastinate B2C users after installed base benefits.
                    <br><br>
                    Dramatically visualize customer directed convergence without revolutionary ROI.
                  </div>
                  <div class="tab-pane" id="schedule-1">
                    Efficiently unleash cross-media information without cross-media value. Quickly maximize timely deliverables for real-time schemas.
                    <br><br>Dramatically maintain clicks-and-mortar solutions without functional solutions.
                  </div>
                  <div class="tab-pane" id="tasks-1">
                    Completely synergize resource taxing relationships via premier niche markets. Professionally cultivate one-to-one customer service with robust ideas.
                    <br><br>Dynamically innovate resource-leveling customer service for state of the art customer service.
                  </div>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>

  </div>
</div>