<div class="container">
  <div class="row py-3">
    <div class="col-md-3 order-2" id="sticky-sidebar">
      <div class="sticky-top">
        <div class="nav flex-column">
          <div class="card p-2">
            <img src="<?= base_url('assets/home/'); ?>assets/img/faces/marc.jpg" width="100%" alt="">
            <h2 class="text-info"><b>Rp. 150.000</b></h2>
            <span><s><b>Rp. 400.000</b></s></span>
            <a href="" class="btn btn-primary">Beli Sekarang</a>
            <a href="<?= base_url('home/kelas/start'); ?>" class="btn btn-primary btn-outline">Mulai</a>
          </div>
        </div>
      </div>
    </div>
    <div class="col-md-9" id="main">
      <h3><b>Project Maanajemen With Kotlin</b></h3>
      <h5>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Consequatur quidem nesciunt quo quod itaque. </h5>




      <section>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Magni explicabo impedit esse pariatur voluptas quas, iste ex corrupti praesentium iure. Assumenda ipsum aperiam tenetur. Commodi eum odio cum hic repudiandae.
      </section>

      <div id="accordion">
        <div class="card">
          <div class="card-header" id="headingOne">
            <h5 class="mb-0">
              <button class="btn btn-link" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                <i class="fa fa-plus"></i> Collapsible Group Item #1
              </button>
            </h5>
          </div>

          <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordion">
            <div class="card-body">
              Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>
</div>