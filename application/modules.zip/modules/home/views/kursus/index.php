<div class="container">

  <div class="row">
    <div class="col-md-3">

      <div class="card" style="overflow: hidden;">
        <img src="<?= base_url('assets/home/'); ?>assets/img/faces/marc.jpg" width="100%" alt="">
        <div class="p-2">
          <a href="<?= base_url('home/kursus/detail'); ?>" class="text-dark">
            <h4 class="px-1"><b>Project Magement with kotlin</b></h4>
          </a>
          <b class="text-muted"> 9 Modul </b><br>
          <b class="text-info"> Rp. 250.000 </b>
        </div>
      </div>
    </div>
  </div>
</div>